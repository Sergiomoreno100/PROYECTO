package com.pf.fisioterapia.service;

import java.util.List;

import com.pf.fisioterapia.model.Paciente;

public interface PacienteService {
	 Paciente createPaciente(Paciente paciente);
	 Paciente updatePaciente(Paciente paciente);
	 void deletePaciente(Long pacienteId);
	 Paciente getPaciente(Long pacienteId);
	 List<Paciente> getPacientes();
	 List<Paciente> searchPacientes(String query);
}
