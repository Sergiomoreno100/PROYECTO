package com.pf.fisioterapia.controller;

import java.util.List;
import java.util.Locale;

import org.springframework.context.MessageSource;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.pf.fisioterapia.dto.TratamientoDTO;
import com.pf.fisioterapia.model.Tratamiento;
import com.pf.fisioterapia.response.ResponseHandler;
import com.pf.fisioterapia.service.TratamientoService;

@RestController
@RequestMapping("/tratamientos")
public class TratamientoController {

	private final TratamientoService tratamientoService;
	private final MessageSource messageSource;

	public TratamientoController(TratamientoService tratamientoService, MessageSource messageSource) {
		this.tratamientoService = tratamientoService;
		this.messageSource = messageSource;
	}


	@GetMapping("/search")
	public List<TratamientoDTO> getTratamientos(@RequestParam Long pacienteId) {
	    if (pacienteId == null || pacienteId <= 0) {
	        throw new IllegalArgumentException("Invalid paciente ID");
	    }
	    return tratamientoService.getTratamientos(pacienteId);
	}

	@PostMapping
	public ResponseEntity<Object> createTratamiento(@RequestBody Tratamiento tratamiento, Locale locale) {
		Tratamiento createdTratamiento = tratamientoService.save(tratamiento);
		String successMessage = messageSource.getMessage("tramiento.creation.success", null, locale);
		return ResponseHandler.responseBuilder(successMessage, HttpStatus.CREATED, createdTratamiento);
	}
}
