package com.pf.fisioterapia.controller;

import java.util.List;

import org.springframework.web.bind.annotation.*;

import com.pf.fisioterapia.model.Sesion;
import com.pf.fisioterapia.service.SesionService;

@RestController
@RequestMapping("/sesiones")
public class SesionController {

    private final SesionService sesionService;

    public SesionController(SesionService sesionService) {
        this.sesionService = sesionService;
    }

    @GetMapping("/{id}")
    public Sesion getSesion(@PathVariable Long id) {
        return sesionService.getById(id);
    }

    @GetMapping
    public List<Sesion> getAllSesiones() {
        return sesionService.getAll();
    }

    @PostMapping
    public Sesion createSesion(@RequestBody Sesion sesion) {
        return sesionService.save(sesion);
    }

    @PutMapping("/{id}")
    public Sesion updateSesion(@PathVariable Long id, @RequestBody Sesion sesion) {
        return sesionService.save(sesion);
    }

    @DeleteMapping("/{id}")
    public void deleteSesion(@PathVariable Long id) {
        sesionService.deleteById(id);
    }
}
