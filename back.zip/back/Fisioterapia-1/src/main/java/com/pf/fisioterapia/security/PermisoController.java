package com.pf.fisioterapia.security;

import java.util.List;

import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/permisos")
public class PermisoController {

    private final PermisoService permisoService;

    public PermisoController(PermisoService permisoService) {
        this.permisoService = permisoService;
    }

    @GetMapping("/{id}")
    public Permiso getPermiso(@PathVariable Long id) {
        return permisoService.getById(id);
    }

    @GetMapping
    public List<Permiso> getAllPermisos() {
        return permisoService.getAll();
    }

    @PostMapping
    public Permiso createPermiso(@RequestBody Permiso permiso) {
        return permisoService.save(permiso);
    }

    @PutMapping("/{id}")
    public Permiso updatePermiso(@PathVariable Long id, @RequestBody Permiso permiso) {
        return permisoService.save(permiso);
    }

    @DeleteMapping("/{id}")
    public void deletePermiso(@PathVariable Long id) {
        permisoService.deleteById(id);
    }
}
