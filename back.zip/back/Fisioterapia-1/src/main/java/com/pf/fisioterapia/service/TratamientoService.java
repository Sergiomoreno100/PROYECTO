package com.pf.fisioterapia.service;

import java.util.List;

import com.pf.fisioterapia.dto.TratamientoDTO;
import com.pf.fisioterapia.model.Tratamiento;

public interface TratamientoService {
	
	Tratamiento save(Tratamiento informe);
    List<TratamientoDTO> getTratamientos(Long idPaciente);
}
