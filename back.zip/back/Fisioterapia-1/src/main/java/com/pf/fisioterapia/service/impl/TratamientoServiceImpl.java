package com.pf.fisioterapia.service.impl;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;

import com.pf.fisioterapia.dto.TratamientoDTO;
import com.pf.fisioterapia.model.Tratamiento;
import com.pf.fisioterapia.repository.TratamientoRepository;
import com.pf.fisioterapia.service.TratamientoService;
import com.pf.fisioterapia.util.Estado;

@Service
public class TratamientoServiceImpl implements TratamientoService {

	private final TratamientoRepository tratamientoRepository;

	public TratamientoServiceImpl(TratamientoRepository tratamientoRepository) {
	        this.tratamientoRepository = tratamientoRepository;
    }

	@Override
	public Tratamiento save(Tratamiento tratamiento) {
		return tratamientoRepository.save(tratamiento);
	}

	@Override
	public List<TratamientoDTO> getTratamientos(Long idPaciente) {
	    List<Tratamiento> tratamientos = tratamientoRepository.findByPacienteId(idPaciente);
	    return tratamientos.stream()
	        .map(tratamiento -> {
	            Estado estado = Estado.fromValue(tratamiento.getEstado()); 
	            return new TratamientoDTO(
	                tratamiento.getFisioterapeuta().getNombre(),
	                tratamiento.getTipoTratamiento(),
	                tratamiento.getDescripcion(),
	                estado.getLabel(),  
	                tratamiento.getFechaInicio().toString()
	            );
	        })
	        .collect(Collectors.toList());
	}
}
