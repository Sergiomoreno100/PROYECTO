package com.pf.fisioterapia.dto;

public class TratamientoDTO {

    private String fisioterapeutaNombre;
    private String tipoTratamiento;
    private String descripcion;
    private String estado;
    private String fechaInicio;

   
    public TratamientoDTO(String fisioterapeutaNombre, String tipoTratamiento, String descripcion, String estado, String fechaInicio) {
        this.fisioterapeutaNombre = fisioterapeutaNombre;
        this.tipoTratamiento = tipoTratamiento;
        this.descripcion = descripcion;
        this.estado = estado;
        this.fechaInicio = fechaInicio;
    }


    public String getFisioterapeutaNombre() {
        return fisioterapeutaNombre;
    }

    public void setFisioterapeutaNombre(String fisioterapeutaNombre) {
        this.fisioterapeutaNombre = fisioterapeutaNombre;
    }

    public String getTipoTratamiento() {
        return tipoTratamiento;
    }

    public void setTipoTratamiento(String tipoTratamiento) {
        this.tipoTratamiento = tipoTratamiento;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public String getFechaInicio() {
        return fechaInicio;
    }

    public void setFechaInicio(String fechaInicio) {
        this.fechaInicio = fechaInicio;
    }
}
