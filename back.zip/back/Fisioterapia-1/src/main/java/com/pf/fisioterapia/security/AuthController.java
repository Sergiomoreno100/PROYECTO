package com.pf.fisioterapia.security;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import jakarta.servlet.http.HttpSession;

@RestController
@RequestMapping("/api/auth")
public class AuthController {

    private final UsuarioService usuarioService;

    public AuthController(UsuarioService usuarioService) {
        this.usuarioService = usuarioService;
    }

    @PostMapping("/login")
    public ResponseEntity<Object> login(@RequestBody LoginRequest loginRequest, HttpSession session) {
        Usuario usuario = usuarioService.findByEmail(loginRequest.getUsername());
        
        if (usuario != null && usuario.getPassword().equals(loginRequest.getPassword())) {
            session.setAttribute("usuario", usuario);
            int role = usuario.getTipoUsuario();
            return ResponseEntity.ok(new LoginResponse("Login successful", role));
        } else {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                    .body(new LoginResponse("Invalid credentials"));
        }
    }
    
    @GetMapping("/check-session")
    public ResponseEntity<Object> checkSession(HttpSession session) {
        if (session.getAttribute("usuario") == null) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Session expired or not authenticated");
        }
        return ResponseEntity.ok("Session is valid");
    }

    static class LoginRequest {
        private String username;
        private String password;

        public String getUsername() { return username; }
        public void setUsername(String username) { this.username = username; }
        public String getPassword() { return password; }
        public void setPassword(String password) { this.password = password; }
    }

    static class LoginResponse {
        private String message;
        private int role;

        public LoginResponse(String message, int role) {
            this.message = message;
            this.role = role;
        }
        
        public LoginResponse(String message) {
            this.message = message;
        }

        public String getMessage() {
            return message;
        }

        public void setMessage(String message) {
            this.message = message;
        }

        public int getRole() {
            return role;
        }

        public void setRole(int role) {
            this.role = role;
        }
    }
}
