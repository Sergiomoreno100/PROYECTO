package com.pf.fisioterapia.service;

import java.util.List;

import com.pf.fisioterapia.model.Sesion;

public interface SesionService {
    Sesion save(Sesion sesion);
    Sesion getById(Long id);
    List<Sesion> getAll();
    void deleteById(Long id);
}
