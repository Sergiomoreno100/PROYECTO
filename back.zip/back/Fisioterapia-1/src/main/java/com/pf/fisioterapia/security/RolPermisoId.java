package com.pf.fisioterapia.security;

import java.io.Serializable;

import lombok.Data;

@Data
public class RolPermisoId implements Serializable {
    private Long rol;
    private Long permiso;
}
