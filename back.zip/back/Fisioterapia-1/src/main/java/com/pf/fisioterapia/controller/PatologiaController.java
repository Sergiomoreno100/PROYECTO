package com.pf.fisioterapia.controller;

import java.util.List;
import java.util.Locale;

import org.springframework.context.MessageSource;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.pf.fisioterapia.model.Patologia;
import com.pf.fisioterapia.response.ResponseHandler;
import com.pf.fisioterapia.service.PatologiaService;

@RestController
@RequestMapping("/patologias")
public class PatologiaController {

    private final PatologiaService patologiaService;
    
    private final MessageSource messageSource;

    public PatologiaController(PatologiaService patologiaService, MessageSource messageSource) {
        this.patologiaService = patologiaService;
        this.messageSource = messageSource;
    }

    @GetMapping("/{id}")
    public Patologia getPatologia(@PathVariable Long id) {
        return patologiaService.getById(id);
    }

    @GetMapping
    public List<Patologia> getAllPatologias() {
        return patologiaService.getAll();
    }
  
    
    @PostMapping
    public ResponseEntity<Object> createPatologia(@RequestBody Patologia patologia, Locale locale) {
        return ResponseHandler.responseBuilder(
        		messageSource.getMessage("paciente.creation.success", null, locale),
        		HttpStatus.CREATED, patologiaService.save(patologia));
    }
    

    @PutMapping("/{id}")
    public Patologia updatePatologia(@PathVariable Long id, @RequestBody Patologia patologia) {
        return patologiaService.save(patologia);
    }

    @DeleteMapping("/{id}")
    public void deletePatologia(@PathVariable Long id) {
        patologiaService.deleteById(id);
    }
}
