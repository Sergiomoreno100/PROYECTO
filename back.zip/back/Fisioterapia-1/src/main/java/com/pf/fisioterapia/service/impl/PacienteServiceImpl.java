package com.pf.fisioterapia.service.impl;

import java.util.List;

import org.springframework.stereotype.Service;

import com.pf.fisioterapia.exception.EntityNotFoundException;
import com.pf.fisioterapia.model.Paciente;
import com.pf.fisioterapia.repository.PacienteRepository;
import com.pf.fisioterapia.service.PacienteService;


@Service
public class PacienteServiceImpl implements PacienteService  {
	
	PacienteRepository pacienteRepository;
	
	public PacienteServiceImpl(PacienteRepository pacienteRepository) {
		this.pacienteRepository = pacienteRepository;
	}
	
	@Override
	public Paciente createPaciente(Paciente paciente) {
		return pacienteRepository.save(paciente);
	}

	@Override
	public Paciente updatePaciente(Paciente paciente) {
		return pacienteRepository.save(paciente);
	}

	@Override
	public void deletePaciente(Long pacienteId) {
		 pacienteRepository.deleteById(pacienteId);
	}

	@Override
	public Paciente getPaciente(Long pacienteId) {
		if(pacienteRepository.findById(pacienteId).isEmpty())
			throw new EntityNotFoundException("Paciente solicitado no existe");
		return pacienteRepository.findById(pacienteId).get();
	}

	@Override
	public List<Paciente> getPacientes() {
		return pacienteRepository.findAll();
	}
	
    @Override
    public List<Paciente> searchPacientes(String query) {
        return pacienteRepository.findByNombreContainingIgnoreCaseOrApellidoContainingIgnoreCase(query, query);
    }
}
