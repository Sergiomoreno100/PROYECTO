package com.pf.fisioterapia.security;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.provisioning.InMemoryUserDetailsManager;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.CorsConfigurationSource;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;
import org.springframework.security.web.SecurityFilterChain;

@Configuration
public class SecurityConfig {
	 
   @Bean
   public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
       http
           .csrf().disable() 
           .cors().configurationSource(corsConfigurationSource()) 
           .and()
           .authorizeHttpRequests(authorize -> authorize
               .requestMatchers(
               		"/public/**",
               		"/api/auth/login", 
               		"/api/auth/check-session", 
               		"/paciente/search", 
               		"/fisioterapeutas/search",
               		"/tratamientos/search")
               .permitAll() 
               .anyRequest().authenticated() 
           )
           .httpBasic(); 
       return http.build();
   }
   
    @Bean
    public CorsConfigurationSource corsConfigurationSource() {
        UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
        CorsConfiguration config = new CorsConfiguration();
        config.setAllowCredentials(true);
        config.addAllowedOriginPattern("http://localhost:8080");
        config.addAllowedHeader("*"); 
        config.addAllowedMethod("*"); 
        source.registerCorsConfiguration("/**", config); 
        return source;
    } 
	
	
	// UserDetailsService with an in-memory user
	@Bean
	public UserDetailsService userDetailsService() {
	    UserDetails user = User.builder()
	        .username("admin")
	        .password("{noop}F1510Ter@p145!") // No password encoding, using {noop} for plain text
	        .roles("USER") // Define user roles
	        .build();
	    return new InMemoryUserDetailsManager(user);
	}
}